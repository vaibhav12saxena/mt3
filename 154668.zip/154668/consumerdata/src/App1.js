import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Form from './components/form'
//There is an error in this code was not able to find the bug
//For making this program work you need to click one button twice for the first time
//Then the program will work
class App extends Component {
   constructor(){
    super();
  this.state=({data:[]});
  }
  
  Addconsumer(t){
  let temp=this.state.data;
  temp.push(t);
  this.setState.data=temp;
  alert(JSON.stringify(this.state.data));
  }



handleDelete(name)
{
  let newdata=this.state.data;
  console.log(newdata);
  let index;
  for(var i=0;i<newdata.length;i++)
  {
        if(newdata[i].UserName==name)
        {
          index=i;
        }
  }

  alert(index);
  newdata.splice(index,1);
  console.log(newdata)
  this.setState({data:newdata})
  
}
  
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Consumer Registration form</h1>
        </header>
        <Form addcon={this.Addconsumer.bind(this)} data={this.state.data} 
        DeleteInfo={this.handleDelete.bind(this)}></Form>
      </div>
    );
  }
}

export default App;
