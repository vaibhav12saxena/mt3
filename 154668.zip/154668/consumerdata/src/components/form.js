import React, { Component } from 'react';

class Form extends Component {
    constructor(){
        super();
        this.state={ consumer:{
                  }
      }}
               add(e){
         this.setState({
             consumer:{
               UserName: this.refs.userName.value,
               EmailId: this.refs.emailId.value,
               Mobile: this.refs.mobile.value,
               Address: this.refs.address.value,
               Pov: this.refs.des.value,
               Date: this.refs.date.value
             }},function(){
                
                this.props.addcon(this.state.consumer)
         })
         e.preventDefault();
        }

        
Delete(name)
{
    alert(name);
    this.props.DeleteInfo(name);
}


                
    render() {
        let cons;
        cons=this.props.data.map(
            oneData=>{
              return(<table class="table">
              <tr><td>Name</td><td>{oneData.UserName}</td></tr>
              <tr><td>EmailId</td>
              <td>{oneData.EmailId}</td></tr>
              <tr><td>Mobile</td><td>{oneData.Mobile}</td></tr>
              <tr><td>Address</td><td>{oneData.Address}</td></tr>
              <tr><td>Purpose of visit</td><td>{oneData.Pov}</td></tr>
              <tr><td>Date</td><td>{oneData.Date}</td>
              <td><button  class="btn btn-warning" onClick={this.Delete.bind(this,oneData.UserName)} data-toggle='tooltip' title='Will delete this item'>Delete</button></td>
            </tr>
            </table>
              )}
          )


      return (
        <div className="container">
        <br/>      
      <form method="get" onSubmit={this.add.bind(this)}>
           <div class="form-group">
        <input type="text" class="form-control" ref="userName" placeholder="Username" required />
           </div>
          <div class="form-group">
        <input type="text" class="form-control" ref="emailId" placeholder="Email Id"  required />
         </div>
       <div class="form-group">
        <input type="number" class="form-control" ref="mobile" placeholder="Mobile number"  required />
         </div>
  <div class="form-group">
        <input type="text" class="form-control" ref="address" placeholder="Address" required />
      </div>
      <div class="form-group">
        <input type="text" class="form-control" ref="des" placeholder="Purpose of visit" required />
      </div>
      <div class="form-group">
        <input type="date" class="form-control" ref="date" placeholder="Date" required />
      </div>
          <br/>
                  <button type="submit" class="btn btn-success" data-toggle='tooltip' title='will Add Employee'>Log in</button>
          </form>
        <br/>
          <div class='panel panel-primary'>
  
  <div class='panel-heading' align='center'>
    <h4> Consumer Visit Information</h4>
  </div>
  <div class='panel-body'>
    <div class='row'>       
    <div class='table-responsive'>
        {cons}
    </div>
</div>
</div>
</div>



</div>
      );
    } 
  }
  
  export default Form;
  