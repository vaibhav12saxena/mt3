var exp=require('express'); //importing express module
var app=exp();  //defining app as a type of express variable
var fr=require('fs'); //importing to handle files
var cors=require('cors') 
var e=[]  //empty array to store filtered values

//Problem 1  Uses readFilesync method of fr to read data from file mobile.json 
//then res.send sends the data to the alloted port (1234 here) 
app.get('/readfile',(req,res)=>{
  res.header("Access-Control-Allow-Origin","*");
  res.header("Acess-Control-Allow-Headers","Origin,X-Requsted-Width,Content-Type,Accept")
  var data =JSON.parse(fr.readFileSync("mobile.json"))
  res.send(data);
  console.log(data)  
});



//Problem 2  Uses readFilesync method of fr to read data from file mobile.json 
//then pushes the condition satisfying data in e res.send sends the data to 
//the alloted port (1234 here)
app.get('/filterread',(req,res)=>{
  res.header("Access-Control-Allow-Origin","*");
  res.header("Acess-Control-Allow-Headers","Origin,X-Requsted-Width,Content-Type,Accept")
  var data =JSON.parse(fr.readFileSync("mobile.json"))
  for (var t=0;t<data.length;t++){
  if (data[t].mobPrice<=50000 && data[t].mobPrice>=10000 ){
  e.push(data[t]);}
  }
  res.send(e)
  console.log("Filtered data reading succesfull")  
});


//Problem 3  Uses readFilesync method of fr to read data from file mobile.json 
//then through for loop searches the index of object to be updated then 
//res.send sends the data to the alloted port (1234 here)
app.get('/update',(req,res)=>{
  res.header("Access-Control-Allow-Origin","*");
  res.header("Acess-Control-Allow-Headers","Origin,X-Requsted-Width,Content-Type,Accept")
  var data =JSON.parse(fr.readFileSync("mobile.json"))
  for (var i=0;i<data.length;i++){
    if(data[i].mobId==1002){
        break;
    }
  }
  data[i].mobName = "Mi"
  fr.writeFileSync(("prob3data.json"),JSON.stringify(data))
  res.send(data)
  console.log("Update succesfull")
});



//Problem1  Uses readFilesync method of fr to read data from file mobile.json 
//then stores new mobile data in newMobile then appends this newMobile in data
//writeFilesync method of fr to write in the file res.send sends the data to the alloted port (1234 here)
app.get('/add',(req,res)=>{
  res.header("Access-Control-Allow-Origin","*");
  res.header("Acess-Control-Allow-Headers","Origin,X-Requsted-Width,Content-Type,Accept")
  var newMobile= {
   
    "mobId": 1006,
    "mobName": "OnePlus 6",
    "mobPrice": 38999,
       }
  var data =JSON.parse(fr.readFileSync("mobile.json"))
  data.push(newMobile)
  fr.writeFileSync(("mobile.json"),JSON.stringify(data))
  res.send(data);
  console.log("Added new mobile")
});

//used to allot the port number for our server
app.use(cors()).listen(1234,()=>{
  console.log("express started");
})

